# Mtpeak-Call

## Run the app

Start the server from this folder with `start-server.cmd` or:

```powershell
node server.mjs
```

The server prints a local URL and any detected private-network URLs. Open the local URL on the host PC.

## Use on the same network

On another device connected to the same Wi-Fi/LAN, open the `Same-network access` URL printed by the server, for example `http://192.168.1.25:3000`. Keep the host PC and server running. If the page cannot connect, allow Node.js through Windows Defender Firewall for **Private networks** and check that the network does not isolate connected devices.

The files in `public/` are the browser app. Server code, `.env`, and `data.json` stay outside that directory; do not move credentials into `public/`.

## Browser calling on other devices

Microphone access for browser calls requires a secure context. The server also prints a `Secure same-network access` URL and an `iPhone certificate` URL at startup.

For iPhone calling on the local network:

1. Open the printed `iPhone certificate` URL in Safari while connected to the same Wi-Fi and install the downloaded profile.
2. In **Settings → General → About → Certificate Trust Settings**, enable full trust for the Mtpeak-Call local root certificate.
3. Open the printed `Secure same-network access` URL and sign in again.

The private PFX stays in the ignored `certs/` folder. Only the public root certificate is served. If the PC's LAN IP changes, recreate the certificate for the new address and trust the new root on the iPhone. The HTTP URL remains available for the rest of the app, but iPhone browser calling requires the trusted HTTPS URL.

## SignalWire

Set the space name, project ID, API token, and caller ID in the root `.env` file or through the admin connection settings. The project API token remains server-side. Trial accounts may restrict calls to verified destination numbers.

## Storage

The local server stores accounts, contacts, activities, and team chat in root `data.json`. Devices on the same host share this data.
