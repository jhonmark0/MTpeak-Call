import assert from 'node:assert/strict';
import test from 'node:test';
import { formatSignalWireError } from '../public/signalwire-error.mjs';

test('formats insufficient-balance envelopes as one short sentence', () => {
  const payload = JSON.stringify({ errors: [{ type: 'account_error', code: 'insufficient_balance', message: 'The account has insufficient balance' }] });
  const error = new Error(`Request failed with status 422: ${payload}`);

  assert.equal(formatSignalWireError(error, 'Call failed.'), 'The account has insufficient balance.');
});

test('maps other known SignalWire codes to concise messages', () => {
  assert.equal(formatSignalWireError({ errors: [{ code: 'unauthorized' }] }, 'Fallback.'), 'SignalWire rejected the API credentials.');
  assert.equal(formatSignalWireError({ code: 'invalid_number' }, 'Fallback.'), 'The destination phone number is invalid.');
});

test('uses a clean fallback instead of displaying generic provider envelopes', () => {
  assert.equal(formatSignalWireError(new Error('Request failed with status 500: {"internal":"stack details"}'), 'Could not send SMS.'), 'Could not send SMS.');
});

test('replaces the SDK media cleanup exception with microphone guidance', () => {
  assert.equal(formatSignalWireError(new Error("Cannot read properties of undefined (reading 'removeEventListener')"), 'Could not connect the call.'), 'The browser could not initialize call audio. Check microphone access and try again.');
});
