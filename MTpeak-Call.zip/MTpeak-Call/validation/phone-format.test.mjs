import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizePhone } from '../phone-format.mjs';

test('formats Philippine numbers without requiring +63', () => {
  assert.equal(normalizePhone('9952909846', 'PH'), '+639952909846');
  assert.equal(normalizePhone('09952909846', 'PH'), '+639952909846');
});

test('formats Korean numbers without requiring +82', () => {
  assert.equal(normalizePhone('09952909846', 'KR'), '+829952909846');
  assert.equal(normalizePhone('9952909846', 'KR'), '+829952909846');
});

test('rejects invalid or incomplete numbers', () => {
  assert.equal(normalizePhone('', 'PH'), null);
  assert.equal(normalizePhone('123', 'KR'), null);
  assert.equal(normalizePhone('+639952909846', 'PH'), '+639952909846');
});
