export function normalizePhone(number, country) {
  const raw = String(number || '').trim();
  const digits = raw.replace(/\D/g, '');
  if (!digits) return null;

  const countryRules = {
    PH: { prefix: '+63', minLength: 10, maxLength: 12 },
    KR: { prefix: '+82', minLength: 9, maxLength: 11 }
  };
  const rule = countryRules[country] || countryRules.PH;

  if (raw.startsWith('+') && digits.length >= rule.minLength && digits.length <= rule.maxLength) {
    return `+${digits}`;
  }

  if (digits.length < rule.minLength || digits.length > rule.maxLength) {
    return null;
  }

  if (country === 'KR') {
    if (digits.startsWith('0')) return `+82${digits.slice(1)}`;
    return `+82${digits}`;
  }

  if (digits.startsWith('0')) return `+63${digits.slice(1)}`;
  return digits.startsWith(rule.prefix.slice(1)) ? `+${digits}` : `+63${digits}`;
}
