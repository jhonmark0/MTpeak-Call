@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>&1
if errorlevel 1 (
    echo Node.js is not installed or not available in PATH.
    pause
    exit /b 1
)

echo Starting Mtpeak-Call server...
node server.mjs
pause