import { createServer } from 'node:http';
import { createServer as createHttpsServer } from 'node:https';
import { readFile, writeFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { networkInterfaces } from 'node:os';
import crypto from 'node:crypto';
import { RestClient, SwmlBuilder } from '@signalwire/sdk';
import { normalizePhone } from './phone-format.mjs';
import { formatSignalWireError } from './public/signalwire-error.mjs';

try {
  const env = await readFile(join(fileURLToPath(new URL('.', import.meta.url)), '.env'), 'utf8');
  env.split(/\r?\n/).forEach((line) => {
    const match = line.match(/^\s*([^#=]+?)\s*=\s*(.*?)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  });
} catch { }

const root = fileURLToPath(new URL('.', import.meta.url));
const publicRoot = join(root, 'public');
const dataFile = join(root, 'data.json');
const preferredPort = Number(process.env.PORT || 3000);
const adminUsername = 'admin';
const adminPassword = 'admin';
const sessions = new Set();
const userSessions = new Map();
const presenceWindow = 45 * 1000;
const mimeTypes = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.cer': 'application/pkix-cert' };

async function readData() {
  return JSON.parse(await readFile(dataFile, 'utf8'));
}

async function saveData(data) {
  await writeFile(dataFile, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
}

async function saveSignalWireEnv(input) {
  const updates = {
    SIGNALWIRE_SPACE: String(input.space || '').trim(),
    SIGNALWIRE_PROJECT_ID: String(input.projectId || '').trim(),
    SIGNALWIRE_VOICE_FROM_NUMBER: String(input.voiceFromNumber || '').trim()
  };
  const apiToken = String(input.apiToken || '').trim();
  if (apiToken) updates.SIGNALWIRE_API_TOKEN = apiToken;

  if (Object.values(updates).some((value) => !value || /[\r\n]/.test(value) || value.length > 1000)) {
    return { error: 'Enter valid SignalWire space, project ID, and voice number values.' };
  }
  if (!updates.SIGNALWIRE_VOICE_FROM_NUMBER.startsWith('+')) {
    return { error: 'Enter the voice number in international format, such as +639495618140.' };
  }
  if (!updates.SIGNALWIRE_API_TOKEN && !process.env.SIGNALWIRE_API_TOKEN) {
    return { error: 'Enter your SignalWire API token.' };
  }

  const envFile = join(root, '.env');
  let contents = '';
  try { contents = await readFile(envFile, 'utf8'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const lines = contents.split(/\r?\n/);
  for (const [key, value] of Object.entries(updates)) {
    let found = false;
    for (let index = 0; index < lines.length; index += 1) {
      if (new RegExp(`^\\s*${key}\\s*=`).test(lines[index])) {
        lines[index] = `${key}=${value}`;
        found = true;
      }
    }
    if (!found) lines.push(`${key}=${value}`);
  }
  await writeFile(envFile, `${lines.join('\n').replace(/\n+$/, '')}\n`, 'utf8');
  Object.assign(process.env, updates);
  return { saved: true, apiTokenConfigured: Boolean(process.env.SIGNALWIRE_API_TOKEN) };
}

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}

async function body(req) {
  let raw = '';
  for await (const chunk of req) raw += chunk;
  return raw ? JSON.parse(raw) : {};
}

async function formBody(req) {
  let raw = '';
  for await (const chunk of req) raw += chunk;
  return Object.fromEntries(new URLSearchParams(raw));
}

function authorized(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  return token && sessions.has(token);
}

function currentUser(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const session = token && userSessions.get(token);
  if (!session) return null;
  session.lastSeen = Date.now();
  return session.accountId;
}

function signalWireConfigured() {
  return Boolean(process.env.SIGNALWIRE_SPACE && process.env.SIGNALWIRE_PROJECT_ID && process.env.SIGNALWIRE_API_TOKEN && (process.env.SIGNALWIRE_FROM_NUMBER || process.env.SIGNALWIRE_VOICE_FROM_NUMBER));
}

function isOnline(accountId) {
  return [...userSessions.values()].some((session) => session.accountId === accountId && Date.now() - session.lastSeen < presenceWindow);
}

async function handleApi(req, res) {
  if (req.method === 'POST' && req.url === '/api/admin/login') {
    const input = await body(req);
    if (input.username !== adminUsername || input.password !== adminPassword) return send(res, 401, { error: 'Invalid admin username or password.' });
    const token = crypto.randomBytes(24).toString('hex');
    sessions.add(token);
    return send(res, 200, { token });
  }

  if (req.url === '/api/admin/signalwire') {
    if (!authorized(req)) return send(res, 401, { error: 'Admin login required.' });
    if (req.method === 'GET') {
      return send(res, 200, {
        space: process.env.SIGNALWIRE_SPACE || '',
        projectId: process.env.SIGNALWIRE_PROJECT_ID || '',
        voiceFromNumber: process.env.SIGNALWIRE_VOICE_FROM_NUMBER || '',
        apiTokenConfigured: Boolean(process.env.SIGNALWIRE_API_TOKEN),
        connected: signalWireConfigured()
      });
    }
    if (req.method === 'PUT') {
      const result = await saveSignalWireEnv(await body(req));
      if (result.error) return send(res, 400, { error: result.error });
      return send(res, 200, { ...result, connected: signalWireConfigured() });
    }
  }

  if (req.url === '/api/data' && !authorized(req)) return send(res, 401, { error: 'Admin login required.' });
  if (req.method === 'GET' && req.url === '/api/data') return send(res, 200, await readData());
  if (req.method === 'PUT' && req.url === '/api/data') {
    const incoming = await body(req);
    if (!incoming || !Array.isArray(incoming.accounts) || !Array.isArray(incoming.activities) || !Array.isArray(incoming.messages) || typeof incoming.settings !== 'object') return send(res, 400, { error: 'Data must include accounts, activities, messages, and settings.' });
    await saveData(incoming);
    return send(res, 200, incoming);
  }

  if (req.method === 'POST' && req.url === '/api/account/register') {
    const input = await body(req);
    if (!input.name || !input.email || !input.password) return send(res, 400, { error: 'Name, email, and password are required.' });
    const data = await readData();
    if (data.accounts.some((account) => account.email === input.email.toLowerCase())) return send(res, 409, { error: 'An account with that email already exists.' });
    const account = { id: crypto.randomUUID(), name: input.name.trim(), email: input.email.trim().toLowerCase(), password: input.password, createdAt: new Date().toISOString() };
    data.accounts.push(account);
    await saveData(data);
    const token = crypto.randomBytes(24).toString('hex');
    userSessions.set(token, { accountId: account.id, lastSeen: Date.now() });
    return send(res, 201, { token, account: { id: account.id, name: account.name, email: account.email } });
  }

  if (req.method === 'POST' && req.url === '/api/account/login') {
    const input = await body(req);
    const data = await readData();
    const account = data.accounts.find((item) => item.email === input.email?.trim().toLowerCase() && item.password === input.password);
    if (!account) return send(res, 401, { error: 'The email or password does not match.' });
    const token = crypto.randomBytes(24).toString('hex');
    userSessions.set(token, { accountId: account.id, lastSeen: Date.now() });
    return send(res, 200, { token, account: { id: account.id, name: account.name, email: account.email } });
  }

  if (req.method === 'GET' && req.url.startsWith('/api/account/profile')) {
    const accountId = currentUser(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const data = await readData();
    const account = data.accounts.find((item) => item.id === accountId);
    if (!account) return send(res, 404, { error: 'Account not found.' });
    const signalWireConnected = signalWireConfigured();
    return send(res, 200, { account: { id: account.id, name: account.name, email: account.email, createdAt: account.createdAt }, settings: { ...data.settings, signalWireStatus: signalWireConnected ? 'Connected' : 'Not connected' }, contacts: (data.contacts || []).filter((contact) => contact.accountId === account.id), activities: data.activities.filter((activity) => activity.accountId === account.id) });
  }

  if (req.method === 'PUT' && req.url === '/api/account/profile') {
    const accountId = currentUser(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const input = await body(req);
    const data = await readData();
    const account = data.accounts.find((item) => item.id === accountId);
    if (!account) return send(res, 404, { error: 'Account not found.' });
    if (!input.name?.trim() || !input.email?.trim() || !input.password) return send(res, 400, { error: 'Name, email, and password are required.' });
    const email = input.email.trim().toLowerCase();
    if (data.accounts.some((item) => item.id !== accountId && item.email === email)) return send(res, 409, { error: 'That email is already in use.' });
    account.name = input.name.trim();
    account.email = email;
    account.password = input.password;
    await saveData(data);
    return send(res, 200, { account: { id: account.id, name: account.name, email: account.email, createdAt: account.createdAt } });
  }

  if (req.method === 'GET' && req.url.startsWith('/api/activity')) {
    const accountId = currentUser(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const data = await readData();
    return send(res, 200, data.activities.filter((activity) => activity.accountId === accountId));
  }
  if (req.method === 'GET' && req.url === '/api/chat') {
    const accountId = currentUser(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const data = await readData();
    return send(res, 200, { workspace: data.settings.workspaceName, accounts: data.accounts.map((account) => ({ id: account.id, name: account.name, email: account.email, online: isOnline(account.id) })), messages: data.messages || [] });
  }
  if (req.method === 'POST' && req.url === '/api/chat') {
    const input = await body(req);
    const accountId = currentUser(req);
    if (!accountId || !input.text?.trim()) return send(res, 400, { error: 'A signed-in account and message are required.' });
    const data = await readData();
    const account = data.accounts.find((item) => item.id === accountId);
    if (!account) return send(res, 401, { error: 'Account not found.' });
    const createdAt = new Date();
    const message = { id: crypto.randomUUID(), accountId: account.id, name: account.name, text: input.text.trim().slice(0, 500), time: createdAt.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }), createdAt: createdAt.toISOString() };
    data.messages = data.messages || [];
    data.messages.push(message);
    data.messages = data.messages.slice(-100);
    await saveData(data);
    return send(res, 201, message);
  }
  if (req.method === 'POST' && req.url === '/api/activity') {
    const input = await body(req);
    const accountId = currentUser(req);
    if (!accountId || !input.number) return send(res, 401, { error: 'You must be logged in.' });
    const data = await readData();
    data.activities.unshift({ number: String(input.number), message: String(input.message || ''), accountId, time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) });
    data.activities = data.activities.slice(0, 20);
    await saveData(data);
    return send(res, 201, data.activities[0]);
  }
  if (req.method === 'POST' && req.url === '/api/calls/token') {
    const accountId = currentUser(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const data = await readData();
    const account = data.accounts.find((item) => item.id === accountId);
    if (!account) return send(res, 401, { error: 'Account not found.' });
    const { SIGNALWIRE_SPACE: space, SIGNALWIRE_PROJECT_ID: projectId, SIGNALWIRE_API_TOKEN: apiToken } = process.env;
    if (!space || !projectId || !apiToken) return send(res, 503, { error: 'SignalWire calling credentials are not configured.' });
    const client = new RestClient({ project: projectId, token: apiToken, host: normalizeSignalWireHost(space) });
    try {
      let subscriberToken;
      try {
        subscriberToken = await client.fabric.tokens.createSubscriberToken({ reference: account.email });
      } catch {
        try {
          await client.fabric.subscribers.create({ email: account.email, displayName: account.name });
        } catch { }
        subscriberToken = await client.fabric.tokens.createSubscriberToken({ reference: account.email });
      }
      if (!subscriberToken?.token) return send(res, 502, { error: 'SignalWire did not return a browser calling token.' });
      return send(res, 200, { token: subscriberToken.token });
    } catch (error) {
      return send(res, 502, { error: formatSignalWireError(error, 'Could not authenticate browser calling with SignalWire.') });
    }
  }
  if (req.method === 'POST' && req.url === '/api/calls') {
    const accountId = currentUser(req);
    const input = await body(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const to = normalizePhone(input.number, input.country || 'PH');
    if (!to) return send(res, 400, { error: 'Enter a valid destination phone number.' });
    const { SIGNALWIRE_SPACE: space, SIGNALWIRE_PROJECT_ID: projectId, SIGNALWIRE_API_TOKEN: apiToken, SIGNALWIRE_FROM_NUMBER: defaultFrom, SIGNALWIRE_VOICE_FROM_NUMBER: voiceFrom } = process.env;
    const from = voiceFrom || defaultFrom;
    if (!space || !projectId || !apiToken || !from) return send(res, 503, { error: 'SignalWire is not configured. Set SIGNALWIRE_SPACE, SIGNALWIRE_PROJECT_ID, SIGNALWIRE_API_TOKEN, and SIGNALWIRE_VOICE_FROM_NUMBER or SIGNALWIRE_FROM_NUMBER on the server.' });
    const host = normalizeSignalWireHost(space);
    const client = new RestClient({ project: projectId, token: apiToken, host });
    const swml = new SwmlBuilder().say(input.message || 'This is a call from Mtpeak-Call.').build();
    let result;
    try {
      result = await client.calling.dial({ from, to, swml });
    } catch (error) {
      return send(res, 502, { error: formatSignalWireError(error, 'SignalWire could not place the call.') });
    }
    if (!result?.id) return send(res, 502, { error: 'SignalWire accepted the request but returned no call ID.' });
    const sid = result.id;
    const status = result.status || 'created';
    const data = await readData();
    data.activities.unshift({ number: to, message: String(input.message || ''), accountId, sid, status, time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) });
    data.activities = data.activities.slice(0, 20);
    await saveData(data);
    return send(res, 201, { sid, status, number: to });
  }
  if (req.method === 'POST' && req.url === '/api/messages') {
    const accountId = currentUser(req);
    const input = await body(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const to = normalizePhone(input.number, input.country || 'PH');
    const text = String(input.message || '').trim();
    if (!to) return send(res, 400, { error: 'Enter a valid destination phone number.' });
    if (!text) return send(res, 400, { error: 'Write a message before sending.' });
    if (text.length > 1600) return send(res, 400, { error: 'SMS messages must be 1600 characters or fewer.' });
    const { SIGNALWIRE_SPACE: space, SIGNALWIRE_PROJECT_ID: projectId, SIGNALWIRE_API_TOKEN: apiToken } = process.env;
    const from = process.env.SIGNALWIRE_FROM_NUMBER || process.env.SIGNALWIRE_VOICE_FROM_NUMBER;
    if (!space || !projectId || !apiToken || !from) return send(res, 503, { error: 'SignalWire is not configured. Set SIGNALWIRE_SPACE, SIGNALWIRE_PROJECT_ID, SIGNALWIRE_API_TOKEN, and SIGNALWIRE_FROM_NUMBER or SIGNALWIRE_VOICE_FROM_NUMBER on the server.' });
    const host = normalizeSignalWireHost(space);
    const params = new URLSearchParams({ To: to, From: from, Body: text });
    const auth = Buffer.from(`${projectId}:${apiToken}`).toString('base64');
    const signalWireResponse = await fetch(`https://${host}/api/laml/2010-04-01/Accounts/${projectId}/Messages.json`, { method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: params });
    const rawResult = await signalWireResponse.text();
    let result = {};
    try { result = rawResult ? JSON.parse(rawResult) : {}; } catch { result = { message: rawResult }; }
    if (!signalWireResponse.ok) return send(res, 400, { error: formatSignalWireError(result, 'SignalWire could not send the SMS.') });
    const data = await readData();
    data.activities.unshift({ number: to, message: text, accountId, sid: result.sid, status: 'SMS sent', type: 'sms', direction: 'outbound', time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) });
    data.activities = data.activities.slice(0, 20);
    await saveData(data);
    return send(res, 201, { sid: result.sid, number: to });
  }
  if (req.method === 'POST' && req.url.startsWith('/api/messages/incoming')) {
    const requestUrl = new URL(req.url, 'http://localhost');
    const input = req.headers['content-type']?.includes('application/x-www-form-urlencoded') ? await formBody(req) : await body(req);
    const accountId = requestUrl.searchParams.get('accountId');
    const from = normalizePhone(input.From || input.from, 'PH');
    const text = String(input.Body || input.body || '').trim();
    const data = await readData();
    if (!accountId || !data.accounts.some((account) => account.id === accountId)) return send(res, 400, { error: 'A valid accountId query parameter is required.' });
    if (!from || !text) return send(res, 400, { error: 'Incoming messages require a sender and message body.' });
    data.activities.unshift({ number: from, message: text, accountId, status: 'Received', type: 'sms', direction: 'inbound', time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) });
    data.activities = data.activities.slice(0, 20);
    await saveData(data);
    return send(res, 201, { ok: true });
  }
  if (req.method === 'POST' && req.url === '/api/contacts') {
    const accountId = currentUser(req);
    const input = await body(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    if (!input.name?.trim() || !input.number?.trim()) return send(res, 400, { error: 'Contact name and phone number are required.' });
    const data = await readData();
    const country = 'PH';
    const prefix = '+63';
    const enteredNumber = input.number.trim();
    const number = enteredNumber.startsWith('+') ? enteredNumber : `${prefix} ${enteredNumber}`;
    const contact = { id: crypto.randomUUID(), accountId, name: input.name.trim(), number, country };
    data.contacts = data.contacts || [];
    data.contacts.push(contact);
    await saveData(data);
    return send(res, 201, contact);
  }
  if (req.method === 'DELETE' && req.url === '/api/activity') {
    const accountId = currentUser(req);
    if (!accountId) return send(res, 401, { error: 'You must be logged in.' });
    const data = await readData();
    data.activities = data.activities.filter((activity) => activity.accountId !== accountId);
    await saveData(data);
    return send(res, 200, { ok: true });
  }

  return send(res, 404, { error: 'Not found.' });
}

function xmlEscape(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&apos;', '"': '&quot;' }[character]));
}

function normalizeSignalWireHost(space) {
  const normalized = String(space || '').trim();
  if (!normalized) return '';
  if (/^https?:\/\//i.test(normalized)) return new URL(normalized).host;
  return normalized.toLowerCase().endsWith('.signalwire.com') ? normalized.toLowerCase() : `${normalized.toLowerCase()}.signalwire.com`;
}

async function serve(req, res) {
  const requestedUrl = new URL(req.url, `http://${req.headers.host || '127.0.0.1:3000'}`);
  const requested = requestedUrl.pathname === '/' ? '/index.html' : requestedUrl.pathname;
  const filePath = normalize(join(publicRoot, requested.replace(/^[/\\]+/, '')));
  if (filePath !== publicRoot && !filePath.startsWith(`${publicRoot}${process.platform === 'win32' ? '\\' : '/'}`)) return send(res, 404, { error: 'Not found.' });
  try {
    let content = await readFile(filePath);
    if (extname(filePath) === '.html') content = Buffer.from(content.toString().replaceAll('Dialtone', 'Mtpeak-Call').replaceAll('dialtone', 'Mtpeak-Call').replaceAll('<span class="logo-mark">◒</span>', '<img class="brand-logo" src="Logo.png" alt="Mtpeak-Call logo">').replaceAll('https://img.sanishtech.com/u/1d56992cae75861aaff27bbbd073061b.png', 'Logo.png'));
    send(res, 200, content, mimeTypes[extname(filePath)] || 'application/octet-stream');
  } catch {
    send(res, 404, 'Not found.', 'text/plain');
  }
}

export { handleApi };

async function handleRequest(req, res) {
  try {
    if (req.url.startsWith('/api/')) await handleApi(req, res);
    else await serve(req, res);
  } catch (error) {
    send(res, 500, { error: error.message || 'Server error.' });
  }
}

function privateLanAddresses() {
  return [...new Set(Object.values(networkInterfaces()).flat().filter((entry) => {
    if (!entry || entry.internal || entry.family !== 'IPv4') return false;
    return entry.address.startsWith('10.') || entry.address.startsWith('192.168.') || /^172\.(1[6-9]|2\d|3[01])\./.test(entry.address);
  }).map((entry) => entry.address))];
}

function startHttpServer(port) {
  const server = createServer(handleRequest);
  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE' && port < preferredPort + 20) {
      console.warn(`HTTP port ${port} is busy. Retrying on port ${port + 1}...`);
      startHttpServer(port + 1);
      return;
    }
    throw error;
  });
  server.listen(port, '0.0.0.0', () => {
    console.log(`Mtpeak-Call running locally at http://localhost:${port}`);
    privateLanAddresses().forEach((address) => console.log(`Same-network access: http://${address}:${port}`));
  });
}

async function startHttpsServer(port) {
  const pfxFile = join(root, 'certs', 'mtpeak-local.pfx');
  if (!process.env.MTPEAK_HTTPS_PFX_PASSWORD) {
    console.warn('Local HTTPS is disabled: MTPEAK_HTTPS_PFX_PASSWORD is missing from .env.');
    return;
  }
  let pfx;
  try { pfx = await readFile(pfxFile); } catch {
    console.warn('Local HTTPS is disabled: certs/mtpeak-local.pfx was not found.');
    return;
  }
  const server = createHttpsServer({ pfx, passphrase: process.env.MTPEAK_HTTPS_PFX_PASSWORD }, handleRequest);
  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE' && port < Number(process.env.HTTPS_PORT || 3443) + 20) {
      console.warn(`HTTPS port ${port} is busy. Retrying on port ${port + 1}...`);
      startHttpsServer(port + 1);
      return;
    }
    console.error(`Local HTTPS failed to start: ${error.message}`);
  });
  server.listen(port, '0.0.0.0', () => {
    console.log(`Secure local access: https://localhost:${port}`);
    privateLanAddresses().forEach((address) => {
      console.log(`Secure same-network access: https://${address}:${port}`);
      console.log(`iPhone certificate: http://${address}:${preferredPort}/mtpeak-local-root.cer`);
    });
  });
}

startHttpServer(preferredPort);
await startHttpsServer(Number(process.env.HTTPS_PORT || 3443));
