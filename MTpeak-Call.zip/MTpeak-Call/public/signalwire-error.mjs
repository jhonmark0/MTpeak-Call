const friendlyMessages = {
  insufficient_balance: 'The account has insufficient balance.',
  unauthorized: 'SignalWire rejected the API credentials.',
  invalid_credentials: 'SignalWire rejected the API credentials.',
  forbidden: 'The SignalWire API token does not have permission for this action.',
  insufficient_permissions: 'The SignalWire API token does not have permission for this action.',
  invalid_number: 'The destination phone number is invalid.',
  invalid_destination: 'The destination phone number is invalid.',
  invalid_phone_number: 'The destination phone number is invalid.',
  rate_limited: 'SignalWire is temporarily limiting requests. Try again shortly.'
};

function cleanProviderPayload(payload) {
  if (!payload) return '';
  if (typeof payload === 'string') {
    const text = payload.trim();
    if (/removeEventListener/i.test(text)) return 'The browser could not initialize call audio. Check microphone access and try again.';
    const jsonStart = text.indexOf('{');
    if (jsonStart >= 0) {
      try { return cleanProviderPayload(JSON.parse(text.slice(jsonStart))); } catch { }
    }
    try { return cleanProviderPayload(JSON.parse(text)); } catch { }
    if (/^(request failed|http(?: error)?\s+\d{3}|status\s+\d{3}|fetch failed|error:)/i.test(text)) return '';
    return text;
  }
  if (Array.isArray(payload)) return payload.map(cleanProviderPayload).find(Boolean) || '';
  if (typeof payload !== 'object') return '';

  const errors = Array.isArray(payload.errors) ? payload.errors : [];
  const items = [...errors, payload];
  for (const item of items) {
    const code = String(item?.code || item?.error || '').toLowerCase();
    if (friendlyMessages[code]) return friendlyMessages[code];
  }
  for (const item of items) {
    const message = item?.message;
    if (typeof message === 'string' && message.trim()) return cleanProviderPayload(message);
  }
  return '';
}

export function formatSignalWireError(error, fallback) {
  const candidates = [error?.response?.data, error?.body, error?.data, error?.message, error];
  for (const candidate of candidates) {
    const message = cleanProviderPayload(candidate);
    if (message) return message;
  }
  return fallback;
}