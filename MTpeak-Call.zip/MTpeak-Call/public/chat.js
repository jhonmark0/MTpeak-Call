const serverOrigin = window.location.origin;
const userAuthKeys = ['dialtone-account', 'dialtone-session', 'dialtone-user-token'];

function getUserAuthValue(key) {
  return sessionStorage.getItem(key) || localStorage.getItem(key);
}

function clearUserAuth() {
  userAuthKeys.forEach((key) => {
    sessionStorage.removeItem(key);
    localStorage.removeItem(key);
  });
}

function account() {
  try { return JSON.parse(getUserAuthValue('dialtone-account')); } catch { return null; }
}

function apiFetch(url, options = {}) {
  return fetch(url, { ...options, headers: { ...(options.headers || {}), Authorization: `Bearer ${getUserAuthValue('dialtone-user-token') || ''}` } });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
}

function setupNavigation() {
  document.querySelectorAll('nav').forEach((nav) => {
    if (!nav.querySelector('a[href="sms.html"]')) {
      const smsLink = document.createElement('a');
      smsLink.className = 'nav-link';
      smsLink.href = 'sms.html';
      smsLink.innerHTML = '<span class="nav-icon">✉</span> SMS messaging';
      const dialerLink = nav.querySelector('a[href="index.html"]');
      const activityLink = nav.querySelector('a[href="activity.html"]');
      nav.insertBefore(smsLink, activityLink || (dialerLink ? dialerLink.nextElementSibling : null) || nav.querySelector('.nav-heading-spaced') || null);
    }
    if (!nav.querySelector('a[href="chat.html"]')) {
      const chatLink = document.createElement('a');
      chatLink.className = 'nav-link';
      chatLink.href = 'chat.html';
      chatLink.innerHTML = '<span class="nav-icon">◌</span> Team chat';
      const manageHeading = nav.querySelector('.nav-heading-spaced');
      nav.insertBefore(chatLink, manageHeading || null);
    }
    setupMobileMenu(nav);
  });
  document.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', () => {
    document.querySelectorAll('.nav-link').forEach((item) => item.classList.remove('selected'));
    link.classList.add('selected');
  }));
}

function setupMobileMenu(nav) {
  const sidebar = nav.closest('.sidebar');
  if (!sidebar || sidebar.querySelector('.mobile-menu-toggle')) return;
  const profile = sidebar.querySelector('.profile-switcher');
  const profilePlaceholder = profile ? document.createComment('profile-switcher-home') : null;
  profile?.before(profilePlaceholder);
  nav.id ||= 'primary-navigation';
  const button = document.createElement('button');
  button.className = 'mobile-menu-toggle';
  button.type = 'button';
  button.setAttribute('aria-controls', nav.id);
  button.setAttribute('aria-expanded', 'false');
  button.setAttribute('aria-label', 'Open navigation menu');
  button.innerHTML = '<span aria-hidden="true">☰</span><small>Menu</small>';
  sidebar.querySelector('.logo')?.after(button);
  const mobileViewport = window.matchMedia('(max-width: 650px)');
  const placeProfile = () => {
    if (!profile || !profilePlaceholder) return;
    if (mobileViewport.matches) nav.prepend(profile);
    else {
      profilePlaceholder.after(profile);
      sidebar.classList.remove('mobile-menu-open');
    }
  };
  placeProfile();
  mobileViewport.addEventListener?.('change', placeProfile);
  const closeMenu = () => {
    sidebar.classList.remove('mobile-menu-open');
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-label', 'Open navigation menu');
  };
  button.addEventListener('click', () => {
    const isOpen = sidebar.classList.toggle('mobile-menu-open');
    button.setAttribute('aria-expanded', String(isOpen));
    button.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
  });
  nav.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeMenu(); });
  document.addEventListener('pointerdown', (event) => { if (!sidebar.contains(event.target)) closeMenu(); });
}

function showMessage(text, kind = 'error') {
  const target = document.querySelector('.form-message');
  target.textContent = text;
  target.className = `form-message ${kind}`;
}

function setupSidebarLogout() {
  const sidebar = document.querySelector('.sidebar-bottom');
  if (!sidebar || sidebar.querySelector('#sidebar-logout')) return;
  const button = document.createElement('button');
  button.id = 'sidebar-logout';
  button.className = 'outline-button sidebar-logout';
  button.type = 'button';
  button.textContent = 'Log out';
  button.addEventListener('click', () => {
    clearUserAuth();
    window.location.href = 'login.html';
  });
  sidebar.append(button);
}

function setupLogoutLink() {
  const link = document.querySelector('#logout');
  if (!link) return;
  link.addEventListener('click', (event) => {
    event.preventDefault();
    clearUserAuth();
    window.location.href = 'login.html';
  });
}

async function loadChat() {
  const currentAccount = account();
  if (!currentAccount) { window.location.replace('login.html'); return; }
  try {
    const response = await apiFetch('/api/chat');
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load team chat.');
    document.querySelectorAll('.profile-switcher strong, .account strong').forEach((element) => { element.textContent = currentAccount.name; });
    document.querySelectorAll('.profile-switcher .profile-avatar, .account .profile-avatar').forEach((element) => { element.textContent = currentAccount.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase(); });
    document.querySelector('.profile-switcher small').textContent = result.workspace;
    document.querySelector('#chat-workspace').textContent = result.workspace;
    renderTeamMembers(result.accounts || [], currentAccount.id);
    renderMessages(result.messages);
  } catch (error) { showMessage(error.message); }
}

function renderTeamMembers(accounts, currentId) {
  const container = document.querySelector('#team-members-list');
  if (!accounts.length) { container.innerHTML = '<p class="page-empty">No team accounts yet.</p>'; return; }
  container.innerHTML = accounts.map((member) => `<div class="team-member"><span class="profile-avatar">${escapeHtml(member.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase())}</span><span><strong>${escapeHtml(member.name)}${member.id === currentId ? ' (you)' : ''}</strong><small>${escapeHtml(member.email)}</small></span><i class="${member.online ? 'online' : 'offline'}" title="${member.online ? 'Online' : 'Offline'}"></i></div>`).join('');
}

function renderMessages(messages) {
  const container = document.querySelector('#chat-messages');
  if (!messages.length) { container.innerHTML = '<p class="page-empty">No messages yet. Start the team conversation.</p>'; return; }
  let previousDate = '';
  container.innerHTML = messages.map((message) => {
    const messageDate = message.createdAt ? new Date(message.createdAt) : new Date();
    const dateKey = `${messageDate.getFullYear()}-${messageDate.getMonth()}-${messageDate.getDate()}`;
    const dateSeparator = dateKey === previousDate ? '' : `<div class="chat-date">${formatChatDate(messageDate)}</div>`;
    previousDate = dateKey;
    return `${dateSeparator}<div class="chat-message"><span class="profile-avatar">${escapeHtml(message.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase())}</span><div><strong>${escapeHtml(message.name)}</strong><small>${escapeHtml(message.time)}</small><p>${escapeHtml(message.text)}</p></div></div>`;
  }).join('');
  container.scrollTop = container.scrollHeight;
}

function formatChatDate(date) {
  return date.toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' });
}

document.querySelector('#chat-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const input = document.querySelector('#chat-message');
  const button = event.currentTarget.querySelector('button');
  const currentAccount = account();
  button.disabled = true;
  try {
    const response = await apiFetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: input.value }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not send message.');
    input.value = '';
    await loadChat();
  } catch (error) { showMessage(error.message); }
  button.disabled = false;
});

setupNavigation();
setupSidebarLogout();
setupLogoutLink();
loadChat();
setInterval(loadChat, 15000);
