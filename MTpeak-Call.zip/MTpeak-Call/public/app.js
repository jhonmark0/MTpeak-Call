const serverOrigin = window.location.origin;
const userAuthKeys = ['dialtone-account', 'dialtone-session', 'dialtone-user-token'];

function getUserAuthValue(key) {
  return sessionStorage.getItem(key) || localStorage.getItem(key);
}

function setUserAuth(result, remember = false) {
  clearUserAuth();
  const storage = remember ? localStorage : sessionStorage;
  storage.setItem('dialtone-account', JSON.stringify(result.account));
  storage.setItem('dialtone-user-token', result.token);
  storage.setItem('dialtone-session', 'active');
}

function setUserAuthValue(key, value) {
  const storage = localStorage.getItem('dialtone-user-token') ? localStorage : sessionStorage;
  storage.setItem(key, value);
}

function clearUserAuth() {
  userAuthKeys.forEach((key) => {
    sessionStorage.removeItem(key);
    localStorage.removeItem(key);
  });
}

const getAccount = () => {
  try {
    return JSON.parse(getUserAuthValue('dialtone-account')) || null;
  } catch {
    return null;
  }
};

function formatDialNumber(rawNumber, country) {
  const raw = String(rawNumber || '').trim();
  const digits = String(rawNumber || '').replace(/\D/g, '');
  if (!digits) return null;
  const prefixes = { PH: '+63', KR: '+82' };
  const prefix = prefixes[country] || prefixes.PH;
  if (raw.startsWith('+')) return digits.startsWith(prefix.slice(1)) ? `+${digits}` : null;
  if (digits.startsWith(prefix.slice(1))) return `+${digits}`;
  const normalized = digits.replace(/^0/, '');
  return `${prefix}${normalized}`;
}


function apiFetch(url, options = {}) {
  return fetch(url, { ...options, headers: { ...(options.headers || {}), Authorization: `Bearer ${getUserAuthValue('dialtone-user-token') || ''}` } });
}

async function friendlySignalWireError(error, fallback) {
  try {
    const { formatSignalWireError } = await import('./signalwire-error.mjs');
    return formatSignalWireError(error, fallback);
  } catch {
    return fallback;
  }
}

function requireLogin() {
  if (document.querySelector('[data-requires-login]') && (!getAccount() || !getUserAuthValue('dialtone-user-token'))) window.location.replace('login.html');
}

function setupNavigation() {
  document.querySelectorAll('nav').forEach((nav) => {
    if (!nav.querySelector('a[href="sms.html"]')) {
      const smsLink = document.createElement('a');
      smsLink.className = 'nav-link';
      smsLink.href = 'sms.html';
      smsLink.innerHTML = '<span class="nav-icon">✉</span> SMS messaging';
      const manageHeading = nav.querySelector('.nav-heading-spaced');
      const activityLink = nav.querySelector('a[href="activity.html"]');
      nav.insertBefore(smsLink, activityLink || manageHeading || null);
    }
    if (!nav.querySelector('a[href="chat.html"]')) {
      const chatLink = document.createElement('a');
      chatLink.className = 'nav-link';
      chatLink.href = 'chat.html';
      chatLink.innerHTML = '<span class="nav-icon">◌</span> Team chat';
      const manageHeading = nav.querySelector('.nav-heading-spaced');
      nav.insertBefore(chatLink, manageHeading || null);
    }
    setupMobileMenu(nav);
  });
  document.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', () => {
    document.querySelectorAll('.nav-link').forEach((item) => item.classList.remove('selected'));
    link.classList.add('selected');
  }));
}

function setupMobileMenu(nav) {
  const sidebar = nav.closest('.sidebar');
  if (!sidebar || sidebar.querySelector('.mobile-menu-toggle')) return;
  const profile = sidebar.querySelector('.profile-switcher');
  const profilePlaceholder = profile ? document.createComment('profile-switcher-home') : null;
  profile?.before(profilePlaceholder);
  nav.id ||= 'primary-navigation';
  const button = document.createElement('button');
  button.className = 'mobile-menu-toggle';
  button.type = 'button';
  button.setAttribute('aria-controls', nav.id);
  button.setAttribute('aria-expanded', 'false');
  button.setAttribute('aria-label', 'Open navigation menu');
  button.innerHTML = '<span aria-hidden="true">☰</span><small>Menu</small>';
  sidebar.querySelector('.logo')?.after(button);
  const mobileViewport = window.matchMedia('(max-width: 650px)');
  const placeProfile = () => {
    if (!profile || !profilePlaceholder) return;
    if (mobileViewport.matches) nav.prepend(profile);
    else {
      profilePlaceholder.after(profile);
      sidebar.classList.remove('mobile-menu-open');
    }
  };
  placeProfile();
  mobileViewport.addEventListener?.('change', placeProfile);
  const closeMenu = () => {
    sidebar.classList.remove('mobile-menu-open');
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-label', 'Open navigation menu');
  };
  button.addEventListener('click', () => {
    const isOpen = sidebar.classList.toggle('mobile-menu-open');
    button.setAttribute('aria-expanded', String(isOpen));
    button.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
  });
  nav.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeMenu(); });
  document.addEventListener('pointerdown', (event) => { if (!sidebar.contains(event.target)) closeMenu(); });
}

function setupSidebarLogout() {
  const sidebar = document.querySelector('.sidebar-bottom');
  if (!sidebar || document.querySelector('#sidebar-logout')) return;
  const button = document.createElement('button');
  button.id = 'sidebar-logout';
  button.className = 'outline-button sidebar-logout';
  button.type = 'button';
  button.textContent = 'Log out';
  button.addEventListener('click', () => {
    clearUserAuth();
    window.location.href = 'login.html';
  });
  sidebar.append(button);
}

function setupLogoutButtons() {
  document.querySelectorAll('#logout').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      clearUserAuth();
      window.location.href = 'login.html';
    });
  });
}

function showMessage(element, message, kind = 'error') {
  if (!element) return;
  element.textContent = message;
  element.className = `form-message ${kind}`;
}

async function setupAccountForm() {
  const form = document.querySelector('#account-form');
  if (!form) return;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const name = document.querySelector('#name').value.trim();
    const email = document.querySelector('#account-email').value.trim().toLowerCase();
    const password = document.querySelector('#account-password').value;
    const message = form.querySelector('.form-message');
    if (password.length < 8) {
      showMessage(message, 'Use at least 8 characters for your password.');
      return;
    }
    try {
      const response = await fetch('/api/account/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email, password }) });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result.error || 'Could not create account.');
      setUserAuth(result);
      showMessage(message, 'Account created. Taking you to your workspace...', 'success');
      window.setTimeout(() => { window.location.href = `${serverOrigin}/index.html`; }, 650);
    } catch (error) { showMessage(message, error.message); }
  });
}

function setupLoginForm() {
  const form = document.querySelector('#login-form');
  if (!form) return;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const email = document.querySelector('#email').value.trim().toLowerCase();
    const password = document.querySelector('#password').value;
    const message = form.querySelector('.form-message');
    try {
      const response = await fetch('/api/account/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result.error || 'Could not log in.');
      setUserAuth(result, document.querySelector('#remember')?.checked === true);
      showMessage(message, 'Welcome back. Opening your workspace...', 'success');
      window.setTimeout(() => { window.location.href = 'index.html'; }, 650);
    } catch (error) { showMessage(message, error.message); }
  });

  const googleButton = document.querySelector('#google-login');
  googleButton?.addEventListener('click', () => showMessage(form.querySelector('.form-message'), 'Google sign-in will be connected in the authentication step.'));
}

function setupDialer() {
  const form = document.querySelector('.dial-form');
  if (!form) return;
  const phone = document.querySelector('#phone');
  const country = document.querySelector('#country');
  const countryPrefix = document.querySelector('#country-prefix');
  const message = document.querySelector('#message');
  const callButton = form.querySelector('.call-button');
  const clearButton = document.querySelector('.clear');
  const dialPad = form.querySelector('.dial-pad');
  const activityCard = document.querySelector('.activity-card');
  const recentCalls = document.querySelectorAll('.recent-call');
  const callModal = document.querySelector('#call-modal');
  const contactNumber = document.querySelector('#call-contact-number');
  const callStatus = document.querySelector('#calling-status');
  const endCallButton = document.querySelector('#end-call');
  const dialerCard = document.querySelector('.dialer-card');
  const dialerStatus = document.querySelector('.dialer-status');
  const secureStatus = document.querySelector('.secure');
  const remoteAudio = document.querySelector('#remote-call-audio');
  const muteButton = document.querySelector('#mute-call');
  const speakerButton = document.querySelector('#speaker-call');
  const holdButton = document.querySelector('#hold-call');
  const keypadButton = document.querySelector('#keypad-call');
  const callKeypad = document.querySelector('#call-keypad');
  const audioOutputControl = document.querySelector('#audio-output-control');
  const audioOutput = document.querySelector('#call-audio-output');
  const callDuration = document.querySelector('#call-duration');
  let browserClient = null;
  let activeCall = null;
  let selfParticipant = null;
  let callDurationTimer = null;
  let callStartedAt = 0;
  let callOnHold = false;
  let callAttempt = 0;
  let callConnected = false;
  let canHoldCall = false;
  let canSendDigits = false;
  const terminalCallStatuses = new Set(['disconnected', 'ended', 'failed', 'destroyed', 'hangup', 'rejected', 'busy', 'no-answer', 'canceled', 'cancelled']);
  const savedDialNumber = sessionStorage.getItem('dialtone-dial-number');
  const updateCountryPrefix = () => {
    const prefix = { PH: '+63', KR: '+82' }[country?.value || 'PH'];
    countryPrefix.textContent = prefix;
    countryPrefix.title = `${country?.value || 'PH'} destination`;
    phone.placeholder = country?.value === 'KR' ? '010 1234 5678' : '0917 123 4567';
  };

  if (savedDialNumber) {
    const isKorea = savedDialNumber.startsWith('+82');
    country.value = isKorea ? 'KR' : 'PH';
    phone.value = savedDialNumber.replace(/^\+?(?:63|82)/, '').replace(/\D/g, '');
    updateCountryPrefix();
    sessionStorage.removeItem('dialtone-dial-number');
  }

  const updateDialerReadiness = () => {
    const digits = phone.value.replace(/\D/g, '').length;
    const isReady = (country?.value === 'KR' ? digits >= 9 : digits >= 7);
    const secureAudioReady = window.isSecureContext && typeof navigator.mediaDevices?.getUserMedia === 'function';
    dialerCard?.classList.toggle('dialer-ready', isReady);
    if (dialerStatus) dialerStatus.textContent = isReady ? 'Ready to call' : 'Waiting for number';
    const signalWireConnected = window.signalWireConnected === true;
    callButton.disabled = !isReady || !signalWireConnected || !secureAudioReady || callButton.dataset.pending === 'true';
    callButton.title = !secureAudioReady ? 'Browser calling requires HTTPS and microphone access' : !signalWireConnected ? 'SignalWire is not connected' : isReady ? 'Start call' : 'Enter a phone number';
    if (secureStatus) secureStatus.textContent = !secureAudioReady ? 'Browser calling requires HTTPS on this device' : !signalWireConnected ? 'SignalWire calling is not connected' : isReady ? 'Browser audio ready' : 'Enter a valid mobile number';
  };


  clearButton?.addEventListener('click', () => { phone.value = ''; phone.focus(); updateDialerReadiness(); });
  dialPad?.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.action === 'backspace') phone.value = phone.value.slice(0, -1);
    else phone.value += button.dataset.digit;
    phone.dispatchEvent(new Event('input'));
    phone.focus();
  });
  country?.addEventListener('change', () => {
    updateCountryPrefix();
    updateDialerReadiness();
  });
  phone.addEventListener('input', () => {
    const digitsOnly = phone.value.replace(/\D/g, '');
    phone.value = digitsOnly;
    updateDialerReadiness();
  });
  recentCalls.forEach((contact) => contact.addEventListener('click', () => {
    phone.value = contact.dataset.number;
    phone.focus();
    updateDialerReadiness();
  }));

  function closeCallModal() {
    callModal.hidden = true;
    document.body.classList.remove('call-modal-open');
  }

  function resetCallControls() {
    window.clearInterval(callDurationTimer);
    callDurationTimer = null;
    callStartedAt = 0;
    callDuration.textContent = '00:00';
    remoteAudio.srcObject = null;
    selfParticipant = null;
    callOnHold = false;
    callConnected = false;
    canHoldCall = false;
    canSendDigits = false;
    callKeypad.hidden = true;
    keypadButton.setAttribute('aria-expanded', 'false');
    [muteButton, speakerButton, holdButton, keypadButton].forEach((button) => { button.disabled = true; button.classList.remove('active'); });
    muteButton.querySelector('small').textContent = 'Mute';
    speakerButton.querySelector('small').textContent = 'Speaker';
    holdButton.querySelector('small').textContent = 'Hold';
    endCallButton.querySelector('small').textContent = 'End';
  }

  async function disposeCall() {
    const call = activeCall;
    activeCall = null;
    if (call) {
      try { await call.hangup(); } catch { }
    }
    if (browserClient) {
      try { await browserClient.disconnect(); } catch { }
      browserClient = null;
    }
    resetCallControls();
  }

  endCallButton?.addEventListener('click', async () => {
    if (!activeCall && callButton.dataset.pending === 'true') {
      callAttempt += 1;
      if (browserClient) {
        try { await browserClient.disconnect(); } catch { }
        browserClient = null;
      }
      callButton.dataset.pending = 'false';
      callButton.innerHTML = '<span>◉</span> Start call';
      closeCallModal();
      updateDialerReadiness();
      return;
    }
    if (activeCall) {
      endCallButton.disabled = true;
      callStatus.textContent = 'Ending call...';
      await disposeCall();
      callStatus.textContent = 'Call ended';
      endCallButton.disabled = false;
      callButton.dataset.pending = 'false';
      updateDialerReadiness();
      callModal.classList.remove('call-connected', 'call-failed');
      closeCallModal();
      return;
    }
    closeCallModal();
    callModal.classList.remove('call-connected', 'call-failed');
  });

  muteButton?.addEventListener('click', async () => {
    try { await selfParticipant?.toggleMute(); } catch (error) { callStatus.textContent = await friendlySignalWireError(error, 'Could not mute microphone.'); }
  });
  speakerButton?.addEventListener('click', async () => {
    try { await selfParticipant?.toggleDeaf(); } catch (error) { callStatus.textContent = await friendlySignalWireError(error, 'Could not change speaker audio.'); }
  });
  holdButton?.addEventListener('click', async () => {
    try {
      await activeCall?.toggleHold();
      callOnHold = !callOnHold;
      holdButton.classList.toggle('active', callOnHold);
      holdButton.querySelector('small').textContent = callOnHold ? 'Resume' : 'Hold';
      callStatus.textContent = callOnHold ? 'On hold' : 'Connected';
    } catch (error) { callStatus.textContent = await friendlySignalWireError(error, 'Could not change hold state.'); }
  });
  keypadButton?.addEventListener('click', () => {
    callKeypad.hidden = !callKeypad.hidden;
    keypadButton.setAttribute('aria-expanded', String(!callKeypad.hidden));
  });
  callKeypad?.addEventListener('click', async (event) => {
    const digitButton = event.target.closest('[data-dtmf]');
    if (!digitButton || !activeCall) return;
    try { await activeCall.sendDigits(digitButton.dataset.dtmf); } catch (error) { callStatus.textContent = await friendlySignalWireError(error, 'Could not send keypad tone.'); }
  });
  audioOutput?.addEventListener('change', async () => {
    if (typeof remoteAudio.setSinkId !== 'function') return;
    try { await remoteAudio.setSinkId(audioOutput.value); } catch (error) { callStatus.textContent = await friendlySignalWireError(error, 'Could not change audio output.'); }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!window.isSecureContext || typeof navigator.mediaDevices?.getUserMedia !== 'function') {
      showNotice(activityCard, !window.isSecureContext ? 'Browser calling on this device requires HTTPS. Open the secure app address and allow microphone access.' : 'This browser cannot access a microphone. Use a browser with microphone support.');
      return;
    }
    const cleanNumber = phone.value.replace(/\D/g, '');
    const selectedCountry = country?.value || 'PH';
    if ((selectedCountry === 'KR' && cleanNumber.length < 9) || (selectedCountry === 'PH' && cleanNumber.length < 7)) {
      phone.setCustomValidity('Enter a complete phone number.');
      phone.reportValidity();
      phone.setCustomValidity('');
      return;
    }
    const formattedNumber = formatDialNumber(phone.value, selectedCountry);
    if (!formattedNumber) {
      phone.setCustomValidity('Enter a valid phone number.');
      phone.reportValidity();
      phone.setCustomValidity('');
      return;
    }
    const currentAttempt = ++callAttempt;
    resetCallControls();
    contactNumber.textContent = formattedNumber;
    callStatus.textContent = 'Connecting to SignalWire...';
    callModal.classList.remove('call-connected', 'call-failed');
    callModal.hidden = false;
    document.body.classList.add('call-modal-open');
    callButton.dataset.pending = 'true';
    callButton.disabled = true;
    callButton.innerHTML = '<span>◌</span> Connecting...';
    updateDialerReadiness();
    try {
      const tokenResponse = await apiFetch('/api/calls/token', { method: 'POST' });
      const tokenResult = await readJson(tokenResponse);
      if (!tokenResponse.ok) throw new Error(tokenResult.error || 'Could not start browser calling.');
      if (currentAttempt !== callAttempt) return;
      const { SignalWire, StaticCredentialProvider } = await import('https://esm.sh/@signalwire/js@4.0.0-rc.4?bundle');
      if (currentAttempt !== callAttempt) return;
      browserClient = new SignalWire(new StaticCredentialProvider({ token: tokenResult.token }));
      callStatus.textContent = 'Ringing';
      const call = await browserClient.dial(formattedNumber, { audio: true, video: false, receiveAudio: true, receiveVideo: false });
      if (currentAttempt !== callAttempt) {
        await call.hangup();
        return;
      }
      activeCall = call;
      let activityLogged = false;
      activeCall.remoteStream$.subscribe((stream) => {
        remoteAudio.srcObject = stream;
        remoteAudio.play().catch(() => { callStatus.textContent = 'Click the page to enable call audio'; });
      });
      activeCall.self$.subscribe((self) => {
        selfParticipant = self;
        muteButton.disabled = !callConnected;
        speakerButton.disabled = !callConnected;
        muteButton.setAttribute('aria-label', 'Mute microphone');
        self.audioMuted$.subscribe((muted) => {
          muteButton.classList.toggle('active', muted === true);
          muteButton.setAttribute('aria-pressed', String(muted === true));
          muteButton.querySelector('small').textContent = muted ? 'Unmute' : 'Mute';
          muteButton.setAttribute('aria-label', muted ? 'Unmute microphone' : 'Mute microphone');
        });
        self.deaf$.subscribe((deaf) => {
          speakerButton.classList.toggle('active', deaf === true);
          speakerButton.setAttribute('aria-pressed', String(deaf === true));
          speakerButton.querySelector('small').textContent = deaf ? 'Audio on' : 'Speaker';
          speakerButton.setAttribute('aria-label', deaf ? 'Enable speaker audio' : 'Mute speaker audio');
        });
      });
      activeCall.capabilities$.subscribe((capabilities) => {
        canHoldCall = capabilities.includes('hold');
        canSendDigits = capabilities.includes('sendDigit');
        holdButton.disabled = !callConnected || !canHoldCall;
        keypadButton.disabled = !callConnected || !canSendDigits;
      });
      activeCall.status$.subscribe((status) => {
        const normalizedStatus = String(status).toLowerCase();
        callStatus.textContent = ({ ringing: 'Ringing', connecting: 'Connecting', connected: 'Connected', disconnecting: 'Ending call', disconnected: 'Call ended', ended: 'Call ended', hangup: 'Call ended', rejected: 'Call rejected', busy: 'Line busy', 'no-answer': 'No answer', canceled: 'Call ended', cancelled: 'Call ended', failed: 'Call failed', destroyed: 'Call ended' })[normalizedStatus] || status;
        callModal.classList.toggle('call-connected', normalizedStatus === 'connected');
        callConnected = normalizedStatus === 'connected';
        muteButton.disabled = !callConnected || !selfParticipant;
        speakerButton.disabled = !callConnected || !selfParticipant;
        holdButton.disabled = !callConnected || !canHoldCall;
        keypadButton.disabled = !callConnected || !canSendDigits;
        if (callConnected && !callStartedAt) {
          callStartedAt = Date.now();
          speakerButton.disabled = false;
          callDurationTimer = window.setInterval(() => {
            const elapsed = Math.floor((Date.now() - callStartedAt) / 1000);
            callDuration.textContent = `${String(Math.floor(elapsed / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
          }, 1000);
          if (!activityLogged) {
            activityLogged = true;
            apiFetch('/api/activity', { method: 'POST', body: JSON.stringify({ number: formattedNumber, message: 'Browser audio call' }) }).then(() => renderActivities(activityCard)).catch(() => {});
          }
        }
        if (terminalCallStatuses.has(normalizedStatus)) {
          if (['failed', 'rejected', 'busy', 'no-answer'].includes(normalizedStatus)) callModal.classList.add('call-failed');
          activeCall = null;
          resetCallControls();
          if (browserClient) browserClient.disconnect().catch(() => {});
          browserClient = null;
          callButton.dataset.pending = 'false';
          callButton.innerHTML = '<span>◉</span> Start call';
          updateDialerReadiness();
        }
      });
      if (navigator.mediaDevices?.enumerateDevices && typeof remoteAudio.setSinkId === 'function') {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const outputs = devices.filter((device) => device.kind === 'audiooutput');
        if (outputs.length > 1) {
          audioOutput.innerHTML = '<option value="">System default</option>' + outputs.map((device, index) => `<option value="${escapeHtml(device.deviceId)}">${escapeHtml(device.label || `Speaker ${index + 1}`)}</option>`).join('');
          audioOutputControl.hidden = false;
        }
      }
    } catch (error) {
      if (currentAttempt !== callAttempt) return;
      callStatus.textContent = error.name === 'NotAllowedError' ? 'Allow microphone access to call.' : await friendlySignalWireError(error, 'Could not connect the call.');
      callModal.classList.add('call-failed');
      await disposeCall();
      callButton.dataset.pending = 'false';
      callButton.innerHTML = '<span>◉</span> Start call';
      updateDialerReadiness();
      showNotice(activityCard, await friendlySignalWireError(error, 'Could not connect browser audio.'));
    }
  });
  updateCountryPrefix();
  updateDialerReadiness();
  loadWorkspaceData(activityCard);
}

function setupSmsForm() {
  const form = document.querySelector('#sms-form');
  if (!form) return;
  const phone = document.querySelector('#phone');
  const recipient = document.querySelector('#sms-recipient');
  const country = document.querySelector('#sms-country');
  const message = document.querySelector('#sms-message');
  const count = document.querySelector('#sms-character-count');
  const button = form.querySelector('button[type="submit"]');
  const selectContactButton = document.querySelector('#sms-select-contact');
  const contactPicker = document.querySelector('#contact-picker-modal');
  const contactList = document.querySelector('#contact-picker-list');
  const updateCountryPrefix = () => {
    const isKorea = country.value === 'KR';
    recipient.placeholder = isKorea ? '010 1234 5678' : '0917 123 4567';
  };
  country.addEventListener('change', updateCountryPrefix);
  recipient.addEventListener('input', () => { recipient.value = recipient.value.replace(/\D/g, ''); });
  updateCountryPrefix();
  const updateCount = () => { count.textContent = message.value.length; };
  message.addEventListener('input', updateCount);
  loadSmsHistory();
  setupSmsConversation();
  selectContactButton?.addEventListener('click', async () => {
    contactPicker.hidden = false;
    try {
      const response = await apiFetch('/api/account/profile');
      const profile = await readJson(response);
      if (!response.ok) throw new Error(profile.error || 'Could not load contacts.');
      contactList.innerHTML = profile.contacts?.length ? profile.contacts.map((contact) => `<button class="contact-picker-item" type="button" data-number="${escapeHtml(contact.number.replace(/[^+\d]/g, ''))}" data-country="${escapeHtml(contact.country || (contact.number.startsWith('+82') ? 'KR' : 'PH'))}"><span class="contact-avatar avatar-blue">${escapeHtml(contact.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase())}</span><span><strong>${escapeHtml(contact.name)}</strong><small>${escapeHtml(contact.number)}</small></span><b>›</b></button>`).join('') : '<p class="page-empty">No saved contacts yet.</p>';
      contactList.querySelectorAll('.contact-picker-item').forEach((contact) => contact.addEventListener('click', () => { country.value = contact.dataset.country; updateCountryPrefix(); recipient.value = contact.dataset.number.replace(/\D/g, ''); contactPicker.hidden = true; recipient.focus(); }));
    } catch (error) { contactList.innerHTML = `<p class="page-empty">${escapeHtml(error.message)}</p>`; }
  });
  document.querySelector('#close-contact-picker')?.addEventListener('click', () => { contactPicker.hidden = true; });
  contactPicker?.addEventListener('click', (event) => { if (event.target === contactPicker) contactPicker.hidden = true; });
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    button.disabled = true;
    try {
      const response = await apiFetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ number: recipient.value.trim(), country: country.value, message: message.value.trim() }) });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result.error || 'Could not send SMS.');
      message.value = '';
      updateCount();
      showMessage(form.querySelector('.form-message'), `SMS sent to ${result.number}.`, 'success');
      loadSmsHistory();
    } catch (error) { showMessage(form.querySelector('.form-message'), error.message); }
    button.disabled = false;
  });
}

async function loadSmsHistory() {
  const list = document.querySelector('#sms-history-list');
  const count = document.querySelector('#sms-history-count');
  if (!list) return;
  try {
    const response = await apiFetch('/api/account/profile');
    const profile = await readJson(response);
    if (!response.ok) throw new Error(profile.error || 'Could not load messages.');
    const messages = (profile.activities || []).filter((activity) => activity.type === 'sms');
    count.textContent = messages.length;
    list.innerHTML = messages.length ? messages.map((activity) => `<button class="sms-history-item" type="button" data-number="${escapeHtml(activity.number)}"><span class="sms-history-icon">✉</span><span><strong>${escapeHtml(activity.number)}</strong><small>${escapeHtml(activity.time)} · ${escapeHtml(activity.status || (activity.direction === 'inbound' ? 'Received' : 'SMS sent'))}</small><p>${escapeHtml(activity.message)}</p></span><b>›</b></button>`).join('') : '<p class="page-empty">No sent or received messages yet.</p>';
    list.querySelectorAll('.sms-history-item').forEach((item) => item.addEventListener('click', () => openSmsConversation(item.dataset.number)));
  } catch (error) { list.innerHTML = `<p class="page-empty">${escapeHtml(error.message)}</p>`; }
}

function setupSmsConversation() {
  const modal = document.querySelector('#conversation-modal');
  const closeButton = document.querySelector('#close-conversation');
  const replyForm = document.querySelector('#conversation-reply');
  const replyMessage = document.querySelector('#conversation-message');
  const count = document.querySelector('#conversation-character-count');
  let recipient = '';
  if (!modal || !replyForm) return;
  replyMessage.addEventListener('input', () => { count.textContent = replyMessage.value.length; });
  closeButton.addEventListener('click', () => { modal.hidden = true; });
  modal.addEventListener('click', (event) => { if (event.target === modal) modal.hidden = true; });
  replyForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = replyForm.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      const response = await apiFetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ number: recipient, country: recipient.startsWith('+82') ? 'KR' : 'PH', message: replyMessage.value.trim() }) });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result.error || 'Could not send reply.');
      replyMessage.value = '';
      count.textContent = '0';
      showMessage(replyForm.querySelector('.form-message'), 'Reply sent.', 'success');
      await openSmsConversation(recipient);
      loadSmsHistory();
    } catch (error) { showMessage(replyForm.querySelector('.form-message'), error.message); }
    button.disabled = false;
  });
  window.openSmsConversation = async (number) => {
    recipient = number;
    document.querySelector('#conversation-title').textContent = number;
    document.querySelector('#conversation-thread').innerHTML = '<p class="page-empty">Loading conversation...</p>';
    modal.hidden = false;
    try {
      const response = await apiFetch('/api/account/profile');
      const profile = await readJson(response);
      if (!response.ok) throw new Error(profile.error || 'Could not load conversation.');
      const messages = (profile.activities || []).filter((activity) => activity.type === 'sms' && activity.number === number).reverse();
      document.querySelector('#conversation-thread').innerHTML = messages.length ? messages.map((activity) => `<div class="message-bubble ${activity.direction === 'inbound' ? 'received' : 'sent'}"><p>${escapeHtml(activity.message)}</p><small>${escapeHtml(activity.time)}</small></div>`).join('') : '<p class="page-empty">No messages in this conversation.</p>';
      const thread = document.querySelector('#conversation-thread');
      thread.scrollTop = thread.scrollHeight;
    } catch (error) { document.querySelector('#conversation-thread').innerHTML = `<p class="page-empty">${escapeHtml(error.message)}</p>`; }
  };
}

function setupPolicyModals() {
  const links = document.querySelectorAll('[data-policy]');
  if (!links.length) return;
  const modals = [...document.querySelectorAll('.policy-modal')];
  const closeModals = () => modals.forEach((modal) => { modal.hidden = true; });
  links.forEach((link) => link.addEventListener('click', (event) => {
    event.preventDefault();
    closeModals();
    document.querySelector(`#${link.dataset.policy}-modal`).hidden = false;
  }));
  modals.forEach((modal) => {
    modal.addEventListener('click', (event) => { if (event.target === modal || event.target.closest('.policy-close')) closeModals(); });
  });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModals(); });
}

async function loadWorkspaceData(activityCard) {
  const account = getAccount();
  if (!account) return;
  try {
    const response = await apiFetch('/api/account/profile');
    const profile = await readJson(response);
    if (!response.ok) throw new Error(profile.error || 'Could not load workspace data.');
    renderContacts(profile.contacts || []);
    renderRecentCalls(profile.activities || []);
    renderActivities(activityCard, profile.activities || []);
    updateSignalWireStatus(profile.settings || {});
  } catch (error) { showNotice(activityCard, error.message); }
}

function updateSignalWireStatus(settings) {
  const status = document.querySelector('#signalwire-ready');
  const callButton = document.querySelector('.call-button');
  if (!status) return;
  const connected = settings.signalWireStatus === 'Connected';
  window.signalWireConnected = connected;
  status.classList.toggle('not-ready', !connected);
  status.classList.toggle('connected', connected);
  status.innerHTML = `<i></i> ${connected ? 'Ready to call' : 'Not connected'}`;
  if (callButton) callButton.title = connected ? 'Start a SignalWire call' : 'Connect SignalWire before calling';
  document.querySelector('#phone')?.dispatchEvent(new Event('input'));
}

function selectDialerNumber(rawNumber) {
  const number = String(rawNumber || '');
  const selectedCountry = number.startsWith('+82') ? 'KR' : 'PH';
  const country = document.querySelector('#country');
  const phone = document.querySelector('#phone');
  if (!country || !phone) return;
  country.value = selectedCountry;
  phone.value = number.replace(/^\+?(?:63|82)/, '').replace(/\D/g, '');
  country.dispatchEvent(new Event('change'));
  phone.dispatchEvent(new Event('input'));
}

function renderContacts(contacts) {
  const directory = document.querySelector('#contact-directory');
  if (!directory) return;
  const colors = ['avatar-yellow', 'avatar-blue', 'avatar-lilac'];
  const contactMarkup = contacts.length ? contacts.map((contact, index) => `<a class="directory-contact" href="#phone" data-number="${escapeHtml(contact.number.replace(/[^+\d]/g, ''))}"><span class="contact-avatar ${colors[index % colors.length]}">${escapeHtml(contact.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase())}</span><span><strong>${escapeHtml(contact.name)}</strong><small><span class="contact-flag">${flagFor(contact.country)}</span>${escapeHtml(contact.number)}</small></span><b>◉</b></a>`).join('') : '<p class="directory-empty">No contacts saved yet.</p>';
  directory.innerHTML = contactMarkup;
  document.querySelectorAll('.directory-contact').forEach((contact) => contact.addEventListener('click', () => {
    selectDialerNumber(contact.dataset.number);
    document.querySelector('#phone')?.focus();
  }));
}

function renderRecentCalls(activities) {
  const recentList = document.querySelector('.recent-calls');
  if (!recentList) return;
  if (!activities.length) {
    recentList.innerHTML = '<p class="directory-empty">No recent calls.</p>';
    return;
  }
  recentList.innerHTML = activities.slice(0, 3).map((activity, index) => `<a class="recent-call" href="#phone" data-number="${escapeHtml(activity.number.replace(/[^+\d]/g, ''))}"><span class="contact-avatar ${['avatar-yellow', 'avatar-blue', 'avatar-lilac'][index % 3]}">↗</span><span><strong>${escapeHtml(activity.number)}</strong><small>${escapeHtml(activity.time)} · Saved call</small></span><b class="mini-call">◉</b></a>`).join('');
  recentList.querySelectorAll('.recent-call').forEach((contact) => contact.addEventListener('click', () => {
    selectDialerNumber(contact.dataset.number);
    document.querySelector('#phone')?.focus();
  }));
}

async function renderActivities(card, loadedActivities = null) {
  if (!card) return;
  const container = card.querySelector('.empty-activity');
  let activities = loadedActivities;
  const account = getAccount();
  try {
    if (activities === null) {
      const response = await apiFetch('/api/activity');
      activities = response.ok ? await response.json() : [];
    }
  } catch { activities = []; }
  if (!activities.length) return;
  container.innerHTML = activities.map((activity) => `<div class="activity-entry"><span>↗</span><strong>${escapeHtml(activity.number)}<small>${escapeHtml(activity.time)} · ${escapeHtml(activity.status || 'Call saved')}</small></strong></div>`).join('');
  container.classList.add('has-activity');
  const clear = card.querySelector('.clear-all');
  clear?.addEventListener('click', (event) => {
    event.preventDefault();
    apiFetch('/api/activity', { method: 'DELETE' });
    container.innerHTML = '<div class="empty-icon">◷</div><strong>Your call activity will appear here.</strong><p>Make your first call to get started.</p>';
    container.classList.remove('has-activity');
  }, { once: true });
}

function showNotice(card, text) {
  const existing = card.querySelector('.local-notice');
  existing?.remove();
  const notice = document.createElement('p');
  notice.className = 'local-notice';
  notice.textContent = text;
  card.querySelector('.activity-top').after(notice);
  window.setTimeout(() => notice.remove(), 5000);
}

function personalizeDashboard() {
  const account = getAccount();
  if (!account) return;
  const firstName = account.name.split(' ')[0];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const heading = document.querySelector('h1');
  if (heading) {
    heading.textContent = `${greeting}, ${firstName} `;
    const spark = document.createElement('span');
    spark.className = 'spark';
    spark.textContent = '✳';
    heading.append(spark);
  }
  document.querySelectorAll('.profile-switcher strong, .account strong').forEach((element) => { element.textContent = account.name; });
}

async function personalizeSidebar() {
  const account = getAccount();
  if (!account || !document.querySelector('.sidebar')) return;
  document.querySelectorAll('.profile-switcher strong, .account strong').forEach((element) => { element.textContent = account.name; });
  document.querySelectorAll('.profile-switcher .profile-avatar, .account .profile-avatar').forEach((element) => { element.textContent = account.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase(); });
  try {
    const response = await apiFetch('/api/account/profile');
    const profile = await readJson(response);
    if (response.ok) document.querySelectorAll('.profile-switcher small').forEach((element) => { element.textContent = profile.settings.workspaceName || 'Personal workspace'; });
  } catch { }
}

async function setupStandalonePage() {
  const page = document.querySelector('.workspace-page');
  const account = getAccount();
  if (!page || !account) return;
  try {
    const response = await apiFetch('/api/account/profile');
    const profile = await readJson(response);
    if (!response.ok) throw new Error(profile.error || 'Could not load workspace data.');
    const activityList = document.querySelector('#page-activity-list');
    if (activityList) activityList.innerHTML = profile.activities.length ? profile.activities.map((item) => `<div class="page-activity-row"><span class="activity-entry-icon">↗</span><span><strong>${escapeHtml(item.number)}</strong><small>${escapeHtml(item.time)} · ${escapeHtml(item.status || 'Call saved')}</small></span></div>`).join('') : '<p class="page-empty">No saved calls yet.</p>';
    const contactList = document.querySelector('#page-contact-list');
    if (contactList) {
      renderStandaloneContacts(contactList, profile.contacts || []);
      setupContactForm(contactList, profile.contacts || []);
    }
  } catch (error) {
    const target = document.querySelector('#page-activity-list, #page-contact-list');
    if (target) target.innerHTML = `<p class="page-empty">${escapeHtml(error.message)}</p>`;
  }
  document.querySelector('#page-clear-activity')?.addEventListener('click', async () => {
    await apiFetch('/api/activity', { method: 'DELETE' });
    document.querySelector('#page-activity-list').innerHTML = '<p class="page-empty">No saved calls yet.</p>';
  });
}

function setupContactForm(contactList, contacts) {
  if (document.querySelector('#contact-form')) return;
  const form = document.createElement('form');
  form.id = 'contact-form';
  form.className = 'contact-form';
  form.innerHTML = '<p class="label">ADD CONTACT</p><label class="contact-input-label" for="contact-name">Full name</label><input id="contact-name" type="text" placeholder="e.g. Maria Santos" required><label class="contact-input-label" for="contact-number">Phone number</label><div class="contact-phone-input"><span class="contact-country-fixed">+63</span><input id="contact-number" type="tel" inputmode="numeric" placeholder="917 123 4567" required></div><small class="contact-input-hint">Philippine mobile number</small><button class="small-button" type="submit"><span>＋</span> Save contact</button><p class="form-message" aria-live="polite"></p>';
  contactList.before(form);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const name = document.querySelector('#contact-name').value.trim();
    const number = document.querySelector('#contact-number').value.replace(/[^\d+ ]/g, '').trim();
    try {
      const response = await apiFetch('/api/contacts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, number, country: 'PH' }) });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result.error || 'Could not save contact.');
      contacts.push(result);
      document.querySelector('#contact-name').value = '';
      document.querySelector('#contact-number').value = '';
      renderStandaloneContacts(contactList, contacts);
      showMessage(form.querySelector('.form-message'), 'Contact saved.', 'success');
    } catch (error) { showMessage(form.querySelector('.form-message'), error.message); }
  });
}

function renderStandaloneContacts(container, contacts) {
  container.innerHTML = contacts.length ? contacts.map((contact, index) => `<a class="page-contact-row" href="index.html#dialer" data-number="${escapeHtml(contact.number.replace(/[^+\d]/g, ''))}"><span class="contact-avatar ${['avatar-yellow', 'avatar-blue', 'avatar-lilac'][index % 3]}">${escapeHtml(contact.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase())}</span><span><strong>${escapeHtml(contact.name)}</strong><small>${escapeHtml(contact.number)}</small></span><b>◉</b></a>`).join('') : '<p class="page-empty">No contacts saved yet.</p>';
  container.querySelectorAll('.page-contact-row').forEach((contact) => contact.addEventListener('click', () => { sessionStorage.setItem('dialtone-dial-number', contact.dataset.number); }));
}

async function setupAccountPage() {
  const accountView = document.querySelector('#account-view');
  if (!accountView) return;
  const createView = document.querySelector('#create-account-view');
  const account = getAccount();
  if (!account) return;
  createView.classList.add('hidden');
  accountView.classList.remove('hidden');
  try {
    const response = await apiFetch('/api/account/profile');
    const profile = await readJson(response);
    if (!response.ok) throw new Error(profile.error || 'Could not load account.');
    const initials = profile.account.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase();
    document.querySelector('#account-initials').textContent = initials;
    document.querySelector('#account-name').textContent = profile.account.name;
    document.querySelector('#account-email-display').textContent = profile.account.email;
    document.querySelector('#account-workspace').textContent = profile.settings.workspaceName || 'Personal workspace';
    document.querySelector('#account-created').textContent = new Date(profile.account.createdAt).toLocaleDateString();
    document.querySelector('#account-activity-count').textContent = profile.activities.length;
    const activityView = document.querySelector('#account-activity');
    activityView.innerHTML = profile.activities.length ? profile.activities.slice(0, 8).map((item) => `<div class="account-activity-row"><strong>${escapeHtml(item.number)}</strong><small>${escapeHtml(item.time)} · ${escapeHtml(item.status || 'Call saved')}</small></div>`).join('') : '<p>No saved calls yet.</p>';
    setupAccountEdit(accountView, profile.account);
  } catch (error) { showMessage(accountView.querySelector('.form-message'), error.message); }
  document.querySelector('#logout')?.addEventListener('click', () => { clearUserAuth(); window.location.href = 'login.html'; });
}

function setupAccountEdit(accountView, profile) {
  if (document.querySelector('#profile-form')) return;
  const form = document.createElement('form');
  form.id = 'profile-form';
  form.className = 'profile-form';
  form.innerHTML = '<h3>Edit profile</h3><label>Name<input id="profile-name" required></label><label>Email<input id="profile-email" type="email" required></label><label>Password<input id="profile-password" type="password" minlength="8" required></label><button class="small-button" type="submit">Save profile</button><p class="form-message" aria-live="polite"></p>';
  accountView.querySelector('.account-heading').after(form);
  document.querySelector('#profile-name').value = profile.name;
  document.querySelector('#profile-email').value = profile.email;
  document.querySelector('#profile-password').value = '';
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
      const response = await apiFetch('/api/account/profile', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: document.querySelector('#profile-name').value, email: document.querySelector('#profile-email').value, password: document.querySelector('#profile-password').value }) });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result.error || 'Could not update profile.');
      setUserAuthValue('dialtone-account', JSON.stringify(result.account));
      document.querySelectorAll('.profile-switcher strong, .account strong').forEach((element) => { element.textContent = result.account.name; });
      showMessage(form.querySelector('.form-message'), 'Profile saved.', 'success');
    } catch (error) { showMessage(form.querySelector('.form-message'), error.message); }
  });
}

function flagFor(country) {
  return ({ US: '🇺🇸', GB: '🇬🇧', CA: '🇨🇦', PH: '🇵🇭' }[country] || '🌐');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[character]));
}

async function readJson(response) {
  const raw = await response.text();
  if (!raw.trim()) throw new Error('The server returned an empty response. Run `node server.mjs` first.');
  try { return JSON.parse(raw); } catch { throw new Error(`The server returned an invalid response (${response.status}).`); }
}

requireLogin();
setupAccountForm();
setupLoginForm();
setupDialer();
setupSmsForm();
setupPolicyModals();
personalizeDashboard();
setupLogoutButtons();
setupAccountPage();
setupNavigation();
setupSidebarLogout();
setupStandalonePage();
personalizeSidebar();
