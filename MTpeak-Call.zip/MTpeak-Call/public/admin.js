const serverOrigin = window.location.origin;

const tokenKey = 'dialtone-admin-token';
const loginView = document.querySelector('#admin-login');
const panelView = document.querySelector('#admin-panel');
const loginForm = document.querySelector('#admin-login-form');
const accountsList = document.querySelector('#accounts-list');
const signalWireForm = document.querySelector('#signalwire-form');
let data = { accounts: [], activities: [], settings: {} };

const request = async (url, options = {}) => {
  let response;
  try {
    response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${sessionStorage.getItem(tokenKey) || ''}`, ...(options.headers || {}) } });
  } catch {
    throw new Error('Cannot reach the server. Run `node server.mjs`, then open http://127.0.0.1:3000/admin.html.');
  }
  const raw = await response.text();
  let result = {};
  if (raw.trim()) {
    try { result = JSON.parse(raw); } catch { throw new Error(`Server returned an invalid response (${response.status}).`); }
  }
  if (!response.ok) throw new Error(result.error || 'Request failed.');
  return result;
};

function message(form, text, kind = 'error') {
  const target = form.querySelector('.form-message');
  target.textContent = text;
  target.className = `form-message ${kind}`;
}

async function openPanel() {
  data = await request('/api/data');
  const signalWireSettings = await request('/api/admin/signalwire');
  loginView.classList.add('hidden');
  panelView.classList.remove('hidden');
  renderData();
  document.querySelector('#signalwire-space').value = signalWireSettings.space;
  document.querySelector('#signalwire-project-id').value = signalWireSettings.projectId;
  document.querySelector('#signalwire-voice-from').value = signalWireSettings.voiceFromNumber;
  document.querySelector('#signalwire-token-status').textContent = signalWireSettings.apiTokenConfigured ? 'API token is configured. Leave blank to keep it.' : 'API token is not configured.';
  updateSignalWireStatus(signalWireSettings.connected);
}

function renderData() {
  document.querySelector('#account-count').textContent = data.accounts.length;
  accountsList.innerHTML = data.accounts.length ? data.accounts.map((account) => `<div class="admin-account"><span class="profile-avatar">${account.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><span><strong>${escapeHtml(account.name)}</strong><small>${escapeHtml(account.email)}</small></span><button type="button" class="edit-account" data-edit="${account.id}">Edit account</button><button type="button" data-delete="${account.id}" aria-label="Delete account">×</button></div>`).join('') : '<p class="admin-empty">No accounts have been created yet.</p>';
  document.querySelector('#workspace-name').value = data.settings.workspaceName || '';
}

function updateSignalWireStatus(connected) {
  const status = document.querySelector('#signalwire-connection-status');
  status.textContent = connected ? 'Connected' : 'Not connected';
  status.classList.toggle('connected', connected);
  status.classList.toggle('not-connected', !connected);
}

async function saveData() {
  data = await request('/api/data', { method: 'PUT', body: JSON.stringify(data) });
  renderData();
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await request('/api/admin/login', { method: 'POST', body: JSON.stringify({ username: document.querySelector('#admin-username').value, password: document.querySelector('#admin-password').value }) });
    sessionStorage.setItem(tokenKey, result.token);
    await openPanel();
  } catch (error) { message(loginForm, error.message); }
});

document.querySelector('#admin-logout').addEventListener('click', () => { sessionStorage.removeItem(tokenKey); panelView.classList.add('hidden'); loginView.classList.remove('hidden'); });
document.querySelector('#add-account-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  data.accounts.push({ id: crypto.randomUUID(), name: document.querySelector('#new-name').value.trim(), email: document.querySelector('#new-email').value.trim().toLowerCase(), password: document.querySelector('#new-password').value, createdAt: new Date().toISOString() });
  await saveData();
  form.reset();
});
document.querySelector('#settings-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  delete data.settings.twilioStatus;
  delete data.settings.twilioPhoneNumber;
  data.settings.workspaceName = document.querySelector('#workspace-name').value.trim();
  await saveData();
  message(event.currentTarget, 'Settings saved.', 'success');
});
signalWireForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = signalWireForm.querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    const result = await request('/api/admin/signalwire', {
      method: 'PUT',
      body: JSON.stringify({
        space: document.querySelector('#signalwire-space').value.trim(),
        projectId: document.querySelector('#signalwire-project-id').value.trim(),
        apiToken: document.querySelector('#signalwire-api-token').value,
        voiceFromNumber: document.querySelector('#signalwire-voice-from').value.trim()
      })
    });
    document.querySelector('#signalwire-api-token').value = '';
    document.querySelector('#signalwire-token-status').textContent = result.apiTokenConfigured ? 'API token is configured. Leave blank to keep it.' : 'API token is not configured.';
    updateSignalWireStatus(result.connected);
    message(signalWireForm, 'SignalWire connection details saved.', 'success');
  } catch (error) {
    message(signalWireForm, error.message);
  }
  button.disabled = false;
});
accountsList.addEventListener('click', async (event) => {
  const editButton = event.target.closest('[data-edit]');
  if (editButton) {
    const account = data.accounts.find((item) => item.id === editButton.dataset.edit);
    const row = editButton.closest('.admin-account');
    row.outerHTML = `<form class="admin-account-edit" data-edit-form="${account.id}"><label>Name<input name="name" value="${escapeHtml(account.name)}" required></label><label>Email<input name="email" type="email" value="${escapeHtml(account.email)}" required></label><label>Password<input name="password" value="${escapeHtml(account.password)}" required></label><span class="edit-actions"><button class="small-button" type="submit">Save changes</button><button class="cancel-edit" type="button">Cancel</button></span></form>`;
    return;
  }
  const cancelButton = event.target.closest('.cancel-edit');
  if (cancelButton) { renderData(); return; }
  const button = event.target.closest('[data-delete]');
  if (!button || !window.confirm('Delete this account?')) return;
  data.accounts = data.accounts.filter((account) => account.id !== button.dataset.delete);
  await saveData();
});

accountsList.addEventListener('submit', async (event) => {
  const form = event.target.closest('[data-edit-form]');
  if (!form) return;
  event.preventDefault();
  const account = data.accounts.find((item) => item.id === form.dataset.editForm);
  const values = new FormData(form);
  account.name = values.get('name').trim();
  account.email = values.get('email').trim().toLowerCase();
  account.password = values.get('password');
  await saveData();
});

function escapeHtml(value) { return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character])); }
if (sessionStorage.getItem(tokenKey)) openPanel().catch(() => sessionStorage.removeItem(tokenKey));
